package org.example.st_april_assignment_2_validate_password;

import java.util.Scanner;

public class Main {
	private static Scanner scanner=new Scanner(System.in);
	private static final int MIN_LENGTH = 8;

    public static boolean isLengthok(String password) {
        return password.length() > MIN_LENGTH;
    }

    public static boolean haveDigit(String password) {
        for(int i=0; i < password.length(); i++){
            char symbol = password.charAt(i);
            if(Character.isDigit(symbol)){
                return true;
            }
        }
        return false;
    }

    public static boolean uprandlow(String password) {
        String lwr = password.toLowerCase();
        boolean chk1 = lwr.equals(password);
        String uppr = password.toUpperCase();
        boolean chk2 = uppr.equals(password);
        boolean final_Chk = !chk2 && !chk1;
        return final_Chk;
    }

    public static boolean checkPassword(String password) {
        return isLengthok(password) && haveDigit(password) && uprandlow(password);
    }
	public static void main(String[] args) {
		System.out.print("Enter Password");

		String str=scanner.next();
		boolean flag=checkPassword(str);
		if(flag==true)
			System.out.print("Valid Password");
		else
			System.out.print("Invalid Password");

	}

}
